
import streamlit as st
import pandas as pd

st.set_page_config(page_title="Business Profit Calculator", page_icon="💹", layout="centered")

st.title("💹 Business Profit Calculator")
st.caption("Enter target **profit** and get the required Business, Revenue, Costing split automatically.")

# --- Defaults (you can edit in the UI) ---
DEFAULT_REVENUE_RATE = 0.03
DEFAULT_RATIOS = {
    "Inhouse": {"units": 4, "cost_pct": 0.015},
    "Broker": {"units": 10, "cost_pct": 0.0275},
    "Reference": {"units": 2, "cost_pct": 0.015},
    "Self": {"units": 1, "cost_pct": 0.01},
}

with st.sidebar:
    st.header("⚙️ Settings")
    profit = st.number_input("Target Profit", min_value=0.0, value=675000.0, step=5000.0, format="%.2f")
    revenue_pct = st.number_input("Revenue % of Business", min_value=0.0, max_value=1.0, value=DEFAULT_REVENUE_RATE, step=0.001, format="%.3f")
    st.write("---")
    st.subheader("Business Mix & Cost %")
    ratios = {}
    total_units = 0.0
    for name, cfg in DEFAULT_RATIOS.items():
        col1, col2 = st.columns(2)
        with col1:
            units = st.number_input(f"{name} ratio units", min_value=0.0, value=float(cfg['units']), step=1.0, key=f"{name}_units")
        with col2:
            cost = st.number_input(f"{name} cost %", min_value=0.0, max_value=1.0, value=float(cfg['cost_pct']), step=0.001, format="%.3f", key=f"{name}_cost")
        ratios[name] = {"units": units, "cost_pct": cost}
        total_units += units

# Guard: if total units is zero
if total_units <= 0:
    st.error("Total ratio units must be greater than 0. Increase at least one category's units.")
    st.stop()

# Weighted cost %
weighted_cost_pct = sum((r['units']/total_units)*r['cost_pct'] for r in ratios.values())
margin_pct = revenue_pct - weighted_cost_pct

colA, colB, colC = st.columns(3)
colA.metric("Revenue %", f"{revenue_pct:.2%}")
colB.metric("Weighted Cost %", f"{weighted_cost_pct:.2%}")
colC.metric("Margin %", f"{margin_pct:.2%}")

if margin_pct <= 0:
    st.error("Margin % must be positive (Revenue % should be greater than Weighted Cost %). Adjust settings in the sidebar.")
    st.stop()

# Total business required
total_business = profit / margin_pct

st.success(f"Total Business Required: **{total_business:,.0f}**")

# Build table
rows = []
for name, r in ratios.items():
    share = r["units"] / total_units
    business = total_business * share
    revenue = business * revenue_pct
    cost = business * r["cost_pct"]
    rows.append({
        "Category": name,
        "Share %": share,
        "Business": business,
        "Revenue": revenue,
        "Cost": cost,
    })

df = pd.DataFrame(rows).sort_values("Category").reset_index(drop=True)

totals = pd.DataFrame([{
    "Category": "TOTAL",
    "Share %": df["Share %"].sum(),
    "Business": df["Business"].sum(),
    "Revenue": df["Revenue"].sum(),
    "Cost": df["Cost"].sum(),
}])

st.subheader("Breakdown")
st.dataframe(
    df.style.format({"Share %": "{:.2%}", "Business": "{:,.0f}", "Revenue": "{:,.0f}", "Cost": "{:,.0f}"}),
    use_container_width=True,
    hide_index=True,
)
st.dataframe(
    totals.style.format({"Share %": "{:.2%}", "Business": "{:,.0f}", "Revenue": "{:,.0f}", "Cost": "{:,.0f}"}),
    use_container_width=True,
    hide_index=True,
)

profit_check = float(totals["Revenue"]) - float(totals["Cost"])
st.metric("Profit Check (Revenue - Cost)", f"{profit_check:,.0f}")

st.write("---")
st.caption("Tip: Use the sidebar to adjust business ratios or percentages as your model evolves.")

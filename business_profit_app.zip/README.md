
# Business Profit Calculator (Streamlit)

A simple web app where you enter **Target Profit** and it auto-calculates the **Total Business** required and gives a breakdown by **Inhouse / Broker / Reference / Self** including Revenue and Cost.

## How to run

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the app:
```bash
streamlit run app.py
```

3. Open the local URL shown in the terminal (usually http://localhost:8501).

## Notes
- Change ratios and percentages from the left sidebar.
- Default values match your Excel: Revenue 3%; Cost%: Inhouse 1.5, Broker 2.75, Reference 1.5, Self 1; Ratio units 4:10:2:1.
